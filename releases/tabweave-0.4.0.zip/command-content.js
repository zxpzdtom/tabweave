var e={placeholder:`Search tabs, URLs, groups, history, and commands`,loading:`Searching...`,loadingDesc:`Reading tabs, groups, commands, and history.`,noResults:`No matches found`,noResultsDesc:`Try a tab title, URL, group name, or recent page.`,hint:`Enter to open · ↑↓ to move · Esc to close`,ready:`Ready`,resultCount:`{count} results`,categoryAll:`All`,helpOpen:`Open`,helpMove:`Move`,helpCategory:`Category`,helpClose:`Close`,typeCommand:`Command`,typeTab:`Tab`,typeGroup:`Group`,typeHistory:`History`,pinned:`Pinned`,recent:`Recent`,today:`Today`,yesterday:`Yesterday`,themeMode:`light`},t=`tabweave-command-search-host`,n=160,r=140,i={open:!1,query:``,items:[],activeCategory:`all`,selectedIndex:0,loading:!1,searchTimer:0,searchRequestId:0,repeatDelayTimer:0,repeatTimer:0,repeatDirection:0,jumpScrollAnimation:0,copy:e},a=``,o=null,s=null,c=null,l=null,u=null,d=null;function f(){let e=document.getElementById(t);if(e?.shadowRoot)return o=e.shadowRoot,o;let n=document.createElement(`div`);return n.id=t,n.style.all=`initial`,document.documentElement.append(n),o=n.attachShadow({mode:`open`}),o.innerHTML=`
    <style>
      :host {
        all: initial;
        color-scheme: light;
        --tw-panel: #ffffff;
        --tw-search: #ffffff;
        --tw-item-hover: rgba(24, 24, 27, .045);
        --tw-item-selected: rgba(139, 92, 246, .1);
        --tw-icon-bg: rgba(244, 244, 245, .96);
        --tw-tag-bg: rgba(244, 244, 245, .9);
        --tw-border: rgba(24, 24, 27, .1);
        --tw-shadow-lg: rgba(24, 24, 27, .22);
        --tw-shadow-md: rgba(24, 24, 27, .16);
        --tw-shadow-sm: rgba(24, 24, 27, .08);
        --tw-surface-highlight: rgba(255, 255, 255, .82);
        --tw-backdrop: rgba(0, 0, 0, .08);
        --tw-muted: #71717a;
        --tw-subtle: #a1a1aa;
        --tw-text: #18181b;
        --tw-violet: #8b5cf6;
        --tw-violet-soft: rgba(139, 92, 246, .14);
        --tw-violet-ring: rgba(124, 58, 237, .22);
        --tw-key-bg: rgba(255, 255, 255, .9);
        --tw-tag-command-bg: rgba(139, 92, 246, .1);
        --tw-tag-command-text: #7c3aed;
        --tw-tag-tab-bg: rgba(14, 165, 233, .1);
        --tw-tag-tab-text: #0284c7;
        --tw-tag-group-bg: rgba(16, 185, 129, .1);
        --tw-tag-group-text: #059669;
        --tw-tag-history-bg: rgba(245, 158, 11, .12);
        --tw-tag-history-text: #b45309;
        --tw-chip-bg: rgba(244, 244, 245, .72);
        --tw-chip-text: #a1a1aa;
        --tw-shortcut-bg: rgba(139, 92, 246, .08);
        --tw-shortcut-text: #d4d4d8;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        font-size: 10px;
        line-height: 1.3;
        -webkit-font-smoothing: antialiased;
      }

      *,
      *::before,
      *::after {
        box-sizing: border-box;
        font-family: inherit;
      }

      :host([data-theme="dark"]) {
        color-scheme: dark;
        --tw-panel: #09090b;
        --tw-search: #09090b;
        --tw-item-hover: rgba(255, 255, 255, .04);
        --tw-item-selected: rgba(139, 92, 246, .16);
        --tw-icon-bg: rgba(24, 24, 27, .9);
        --tw-tag-bg: rgba(24, 24, 27, .78);
        --tw-border: rgba(255, 255, 255, .1);
        --tw-shadow-lg: rgba(0, 0, 0, .55);
        --tw-shadow-md: rgba(0, 0, 0, .38);
        --tw-shadow-sm: rgba(0, 0, 0, .22);
        --tw-surface-highlight: rgba(255, 255, 255, .08);
        --tw-backdrop: rgba(0, 0, 0, .14);
        --tw-muted: #71717a;
        --tw-subtle: #52525b;
        --tw-text: #f4f4f5;
        --tw-violet-soft: rgba(139, 92, 246, .16);
        --tw-violet-ring: rgba(196, 181, 253, .25);
        --tw-key-bg: rgba(255, 255, 255, .06);
        --tw-tag-command-bg: rgba(139, 92, 246, .16);
        --tw-tag-command-text: #c4b5fd;
        --tw-tag-tab-bg: rgba(14, 165, 233, .16);
        --tw-tag-tab-text: #7dd3fc;
        --tw-tag-group-bg: rgba(16, 185, 129, .16);
        --tw-tag-group-text: #6ee7b7;
        --tw-tag-history-bg: rgba(245, 158, 11, .16);
        --tw-tag-history-text: #fcd34d;
        --tw-chip-bg: rgba(255, 255, 255, .055);
        --tw-chip-text: #52525b;
        --tw-shortcut-bg: rgba(139, 92, 246, .14);
        --tw-shortcut-text: #3f3f46;
      }

      [hidden] { display: none !important; }

      .backdrop {
        position: fixed;
        inset: 0;
        z-index: 2147483647;
        display: grid;
        align-items: start;
        justify-items: center;
        padding-top: max(80px, 12vh);
        background: var(--tw-backdrop);
      }

      .frame {
        display: flex;
        flex-direction: column;
        width: min(680px, calc(100vw - 32px));
        height: min(560px, calc(100vh - 80px));
        max-height: min(620px, calc(100vh - 80px));
        overflow: hidden;
        overflow-x: hidden;
        border-radius: 22px;
        background:
          var(--tw-panel);
        box-shadow:
          0 42px 120px -44px var(--tw-shadow-lg),
          0 24px 60px -28px var(--tw-shadow-md),
          0 8px 24px -12px var(--tw-shadow-sm),
          inset 0 1px 0 var(--tw-surface-highlight),
          0 0 0 1px var(--tw-border);
      }

      .search {
        display: flex;
        align-items: center;
        gap: 4px;
        flex: 0 0 auto;
        padding: 12px 14px;
        background: var(--tw-search);
        border-bottom: 1px solid var(--tw-border);
      }

      .categories {
        display: flex;
        gap: 8px;
        overflow: auto;
        overflow-x: hidden;
        flex: 0 0 auto;
        padding: 8px 10px;
        border-bottom: 1px solid var(--tw-border);
        scrollbar-width: none;
      }

      .categories::-webkit-scrollbar { display: none; }

      .category {
        display: inline-flex;
        flex: 0 0 auto;
        align-items: center;
        gap: 7px;
        min-height: 28px;
        border: 1px solid var(--tw-border);
        border-radius: 10px;
        padding: 0 10px;
        background: transparent;
        color: var(--tw-muted);
        font-family: inherit;
        font-size: 12px;
        font-weight: 600;
        line-height: 1;
        cursor: pointer;
        transition: background-color .14s ease, border-color .14s ease, color .14s ease, box-shadow .14s ease;
      }

      .category:hover {
        background: var(--tw-item-hover);
        color: var(--tw-text);
      }

      .category[data-active="true"] {
        background: var(--tw-item-selected);
        border-color: var(--tw-violet-ring);
        color: var(--tw-text);
        box-shadow: none;
      }

      .category-count {
        display: inline-flex;
        min-width: 21px;
        height: 20px;
        align-items: center;
        justify-content: center;
        border-radius: 999px;
        padding: 0 6px;
        background: var(--tw-chip-bg);
        color: var(--tw-chip-text);
        font-variant-numeric: tabular-nums;
      }

      .category[data-active="true"] .category-count {
        background: var(--tw-shortcut-bg);
      }

      .mark {
        display: grid;
        width: 30px;
        height: 30px;
        place-items: center;
        color: var(--tw-muted);
        font-family: inherit;
        font-size: 14px;
        font-weight: 700;
        line-height: 1;
      }

      .mark svg {
        width: 16px;
        height: 16px;
      }

      input {
        all: unset;
        flex: 1;
        min-width: 0;
        height: 34px;
        color: var(--tw-text);
        font-family: inherit;
        font-size: 14px;
        font-weight: 500;
        line-height: 34px;
      }

      input::placeholder { color: var(--tw-muted); }

      .esc {
        border-radius: 9px;
        padding: 7px 10px;
        background: var(--tw-tag-bg);
        color: var(--tw-muted);
        font-family: inherit;
        font-size: 12px;
        font-weight: 600;
        line-height: 1;
        box-shadow: inset 0 0 0 1px var(--tw-border);
      }

      .list {
        position: relative;
        min-height: 0;
        flex: 1 1 auto;
        overflow: auto;
        padding: 8px 8px 12px;
        scrollbar-color: #3f3f46 transparent;
        scrollbar-width: thin;
        -webkit-mask-image: linear-gradient(180deg, transparent 0, #000 12px, #000 calc(100% - 18px), transparent 100%);
        mask-image: linear-gradient(180deg, transparent 0, #000 12px, #000 calc(100% - 18px), transparent 100%);
      }

      .item {
        display: flex;
        width: 100%;
        max-width: 100%;
        min-width: 0;
        align-items: center;
        gap: 8px;
        border: 0;
        border-radius: 12px;
        background: transparent;
        padding: 7px 8px;
        color: inherit;
        text-align: left;
        font-family: inherit;
        font-size: 10px;
        font-weight: 400;
        line-height: 1.3;
        transition: background-color .14s ease, transform .14s ease, box-shadow .14s ease;
        cursor: pointer;
      }

      .item:hover,
      .item[data-selected="true"] {
        background: var(--tw-item-selected);
        box-shadow: inset 0 0 0 1px rgba(139, 92, 246, .18);
      }

      .item:hover { background: var(--tw-item-hover); }

      .item[data-selected="true"]:hover { background: var(--tw-item-selected); }

      .item:active { transform: scale(.96); }

      .icon {
        display: grid;
        width: 30px;
        height: 30px;
        place-items: center;
        flex: 0 0 auto;
        overflow: hidden;
        border-radius: 9px;
        background: var(--tw-icon-bg);
        color: var(--tw-violet);
        font-family: inherit;
        font-size: 11px;
        font-weight: 700;
        line-height: 1;
        box-shadow: inset 0 0 0 1px var(--tw-border);
      }

      .icon[data-type="command"] {
        font-size: 17px;
        font-weight: 700;
      }

      .icon img {
        width: 20px;
        height: 20px;
      }

      .icon svg {
        width: 18px;
        height: 18px;
      }

      .copy {
        min-width: 0;
        flex: 1;
        overflow: hidden;
        padding-right: 56px;
      }

      .title {
        overflow: hidden;
        display: block;
        color: var(--tw-text);
        font-family: inherit;
        font-size: 15px;
        line-height: 1.18;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .subtitle {
        margin-top: 1px;
        overflow: hidden;
        display: block;
        color: var(--tw-subtle);
        font-family: inherit;
        font-size: 12.5px;
        line-height: 1.18;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .subtitle:empty { display: none; }

      .section-title {
        position: sticky;
        top: -8px;
        z-index: 1;
        margin: 0 -8px;
        padding: 18px 18px 6px;
        background: var(--tw-panel);
        color: var(--tw-muted);
        font-family: inherit;
        font-size: 10.5px;
        font-weight: 700;
        line-height: 1;
        letter-spacing: .08em;
        text-transform: uppercase;
      }

      .section-title:first-child {
        padding-top: 14px;
      }

      .meta {
        display: inline-flex;
        flex: 0 0 auto;
        align-items: center;
        justify-content: flex-end;
        gap: 6px;
        margin-left: 18px;
      }

      .chip {
        flex: 0 0 auto;
        max-width: 84px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        border-radius: 8px;
        padding: 4px 7px;
        font-family: inherit;
        font-size: 11px;
        line-height: 1;
        letter-spacing: 0;
        box-shadow: none;
      }

      .chip {
        background: var(--tw-chip-bg);
        color: var(--tw-chip-text);
      }

      .chip[data-kind="shortcut"] {
        background: transparent;
        color: var(--tw-shortcut-text);
        font-variant-numeric: tabular-nums;
      }

      .shortcut-mod {
        margin-right: 3px;
      }

      .chip[data-kind="pinned"] {
        color: var(--tw-tag-tab-text);
      }

      .subtitle-type {
        color: var(--tw-muted);
      }

      .empty {
        padding: 42px 24px;
        text-align: center;
      }

      .empty-title {
        color: var(--tw-text);
        font-family: inherit;
        font-size: 14px;
        font-weight: 500;
        line-height: 1.4;
      }

      .empty-desc {
        margin-top: 6px;
        color: var(--tw-muted);
        font-family: inherit;
        font-size: 12px;
        line-height: 1.5;
      }

      .status {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        min-width: 0;
        border-top: 1px solid var(--tw-border);
        flex: 0 0 auto;
        min-height: 38px;
        padding: 10px 16px;
        color: var(--tw-muted);
        font-family: inherit;
        font-size: 11px;
        font-weight: 600;
        line-height: 1.2;
      }

      .status span {
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .help {
        display: flex;
        min-width: 0;
        flex-wrap: wrap;
        align-items: center;
        column-gap: 12px;
        row-gap: 5px;
      }

      .help-item {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        white-space: nowrap;
      }

      .key {
        display: inline-grid;
        min-width: 21px;
        height: 19px;
        place-items: center;
        border-radius: 5px;
        padding: 0 5px;
        background: var(--tw-key-bg);
        color: var(--tw-text);
        font-family: inherit;
        font-size: 10.5px;
        font-weight: 700;
        line-height: 1;
        box-shadow: inset 0 0 0 1px var(--tw-border), 0 1px 1px rgba(0, 0, 0, .04);
      }

      .count {
        display: inline-flex;
        align-items: center;
        flex: 0 0 auto;
        color: var(--tw-subtle);
        font-variant-numeric: tabular-nums;
      }

      @media (max-width: 460px) {
        .backdrop { padding-top: 56px; }
        .frame { width: calc(100vw - 20px); }
        .meta { display: none; }
      }
    </style>
    <div class="backdrop" hidden>
      <div class="frame">
        <div class="search">
          <div class="mark" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="11" cy="11" r="7" />
              <path d="m20 20-3.5-3.5" />
            </svg>
          </div>
          <input autocomplete="off" spellcheck="false" />
          <div class="esc">Esc</div>
        </div>
        <div class="categories"></div>
        <div class="list"></div>
        <div class="status"></div>
      </div>
    </div>
  `,s=o.querySelector(`input`),c=o.querySelector(`.list`),l=o.querySelector(`.status`),u=o.querySelector(`.frame`),d=o.querySelector(`.categories`),o.querySelector(`.backdrop`)?.addEventListener(`click`,e=>{e.target instanceof Element&&e.target.classList.contains(`backdrop`)&&H()}),u?.addEventListener(`click`,e=>e.stopPropagation()),s?.addEventListener(`input`,()=>{i.query=s?.value??``,I()}),o.addEventListener(`keydown`,Q),o.addEventListener(`keyup`,$),o.addEventListener(`focusout`,J),o}function p(e){return e.type===`command`?i.copy.typeCommand:e.type===`group`?i.copy.typeGroup:e.type===`history`?i.copy.typeHistory:i.copy.typeTab}function m(){let e=[{id:`all`,label:i.copy.categoryAll}];return(g(`pinned`)>0||i.activeCategory===`pinned`)&&e.push({id:`pinned`,label:i.copy.pinned}),e.push({id:`tab`,label:i.copy.typeTab},{id:`group`,label:i.copy.typeGroup},{id:`history`,label:i.copy.typeHistory},{id:`command`,label:i.copy.typeCommand}),e}function h(){return i.activeCategory===`all`?i.items:i.activeCategory===`pinned`?i.items.filter(e=>e.pinned):i.items.filter(e=>e.type===i.activeCategory)}function g(e){return e===`all`?i.items.length:e===`pinned`?i.items.filter(e=>e.pinned).length:i.items.filter(t=>t.type===e).length}function _(e){i.activeCategory=e,i.selectedIndex=0,A(),N(),P()}function v(e){let t=m();_(t[(Math.max(0,t.findIndex(e=>e.id===i.activeCategory))+e+t.length)%t.length].id)}function y(e){return e.type===`command`?`⌘`:e.type===`group`?`G`:e.type===`history`?`H`:`T`}function b(){return/mac|iphone|ipad|ipod/i.test(navigator.platform)}function x(e){return e<0||e>8?``:`${b()?`⌘`:`Ctrl`} ${e+1}`}function S(e,t=0){let n=new Date(e),r=new Date;return r.setDate(r.getDate()+t),n.getFullYear()===r.getFullYear()&&n.getMonth()===r.getMonth()&&n.getDate()===r.getDate()}function C(e){if(!e.lastVisitTime||e.type===`command`)return``;let t=Date.now()-e.lastVisitTime;return t>=0&&t<600*1e3?i.copy.recent:S(e.lastVisitTime)?i.copy.today:S(e.lastVisitTime,-1)?i.copy.yesterday:new Intl.DateTimeFormat(void 0,{month:`short`,day:`numeric`}).format(new Date(e.lastVisitTime))}function w(e,t){let n=document.createElement(`span`);return n.className=`chip`,n.dataset.kind=t,n.textContent=e,n}function T(e){let t=w(``,`shortcut`),[n,r]=e.split(` `),i=document.createElement(`span`);i.className=`shortcut-mod`,i.textContent=n;let a=document.createElement(`span`);return a.textContent=r,t.append(i,a),t}function E(e){let t=document.createElement(`span`);t.className=`subtitle`;let n=document.createElement(`span`);return n.className=`subtitle-type`,n.textContent=p(e),t.append(n),e.subtitle&&t.append(document.createTextNode(` · ${e.subtitle}`)),t}function D(e){e.replaceChildren();let t=document.createElementNS(`http://www.w3.org/2000/svg`,`svg`);t.setAttribute(`viewBox`,`0 0 24 24`),t.setAttribute(`fill`,`none`),t.setAttribute(`stroke`,`currentColor`),t.setAttribute(`stroke-width`,`2`),t.setAttribute(`stroke-linecap`,`round`),t.setAttribute(`stroke-linejoin`,`round`),t.setAttribute(`aria-hidden`,`true`);let n=document.createElementNS(`http://www.w3.org/2000/svg`,`rect`);n.setAttribute(`x`,`4`),n.setAttribute(`y`,`5`),n.setAttribute(`width`,`16`),n.setAttribute(`height`,`14`),n.setAttribute(`rx`,`3`);let r=document.createElementNS(`http://www.w3.org/2000/svg`,`path`);r.setAttribute(`d`,`M4 9h16`),t.append(n,r),e.append(t)}function O(){return i.copy.themeMode===`dark`||i.copy.themeMode===`system`&&window.matchMedia(`(prefers-color-scheme: dark)`).matches?`dark`:`light`}function k(){let e=o?.host;e instanceof HTMLElement&&(e.dataset.theme=O())}function A(){d&&d.replaceChildren(...m().map(e=>{let t=document.createElement(`div`);t.role=`button`,t.tabIndex=-1,t.className=`category`,t.dataset.active=String(e.id===i.activeCategory);let n=document.createElement(`span`);n.textContent=e.label;let r=document.createElement(`span`);return r.className=`category-count`,r.textContent=String(g(e.id)),t.append(n,r),t.addEventListener(`pointerdown`,t=>{t.preventDefault(),_(e.id),s?.focus()}),t}))}function j(){let e=h();return i.loading?`loading:${i.copy.loading}:${i.copy.loadingDesc}`:e.length===0?`empty:${i.activeCategory}:${i.copy.noResults}:${i.copy.noResultsDesc}`:`${i.activeCategory}:${e.map(e=>e.id).join(`|`)}`}function M(){c?.querySelectorAll(`.item`).forEach((e,t)=>{e.dataset.selected=String(t===i.selectedIndex)})}function N(){if(!c)return;let e=j();if(e===a){M();return}if(a=e,i.loading){c.innerHTML=`<div class="empty"><div class="empty-title">${i.copy.loading}</div><div class="empty-desc">${i.copy.loadingDesc}</div></div>`;return}let t=h();if(t.length===0){c.innerHTML=`<div class="empty"><div class="empty-title">${i.copy.noResults}</div><div class="empty-desc">${i.copy.noResultsDesc}</div></div>`;return}let n=``,r=t.flatMap((e,t)=>{let r=[],a=C(e);if(a&&a!==n){let e=document.createElement(`div`);e.className=`section-title`,e.textContent=a,r.push(e)}n=a;let o=document.createElement(`div`);o.role=`button`,o.tabIndex=-1,o.className=`item`,o.dataset.selected=String(t===i.selectedIndex),o.addEventListener(`mouseenter`,()=>{i.selectedIndex=t,M(),P(),s?.focus()}),o.addEventListener(`pointerdown`,t=>{t.preventDefault(),z(e)});let c=document.createElement(`span`);if(c.className=`icon`,c.dataset.type=e.type,e.type===`tab`&&e.favIconUrl){let t=document.createElement(`img`);t.src=e.favIconUrl,t.alt=``,t.addEventListener(`error`,()=>{D(c)}),c.append(t)}else e.type===`tab`?D(c):c.textContent=y(e);let l=document.createElement(`span`);l.className=`copy`;let u=document.createElement(`span`);u.className=`title`,u.textContent=e.title,l.append(u,E(e));let d=document.createElement(`span`);d.className=`meta`;let f=x(t);return f&&d.append(T(f)),e.pinned&&d.append(w(i.copy.pinned,`pinned`)),o.append(c,l,d),r.push(o),r});c.replaceChildren(...r)}function P(){l&&(l.innerHTML=`
    <span class="help">
      <span class="help-item"><kbd class="key">↵</kbd> ${i.copy.helpOpen}</span>
      <span class="help-item"><kbd class="key">↑</kbd><kbd class="key">↓</kbd> ${i.copy.helpMove}</span>
      <span class="help-item"><kbd class="key">Tab</kbd> ${i.copy.helpCategory}</span>
      <span class="help-item"><kbd class="key">Esc</kbd> ${i.copy.helpClose}</span>
    </span>
    <span class="count">${h().length>0?i.copy.resultCount.replace(`{count}`,String(h().length)):i.copy.ready}</span>
  `)}function F(){f();let e=o?.querySelector(`.backdrop`);!e||!c||!l||!d||(k(),s&&(s.placeholder=i.copy.placeholder),e.hidden=!i.open,i.open&&(A(),N(),P()))}function I(){window.clearTimeout(i.searchTimer),i.searchTimer=window.setTimeout(()=>{L(i.query)},n)}async function L(e){let t=++i.searchRequestId;i.loading=!0,F();let n=await chrome.runtime.sendMessage({type:`TABWEAVE_SEARCH_COMMANDS`,query:e});t!==i.searchRequestId||e!==i.query||(i.items=n?.ok?n.items??[]:[],i.selectedIndex=0,i.loading=!1,F())}async function R(){let t=await chrome.runtime.sendMessage({type:`TABWEAVE_GET_COMMAND_SEARCH_COPY`});i.copy=t?.ok&&t.copy?t.copy:e}async function z(e){(await chrome.runtime.sendMessage({type:`TABWEAVE_ACTIVATE_COMMAND_ITEM`,item:e}))?.ok&&H()}function B(e){let t=h()[e];t&&z(t)}async function V(){i.open=!0,i.selectedIndex=0,i.activeCategory=`all`,f(),await R(),F(),s?.focus(),I()}function H(){i.open=!1,window.clearTimeout(i.searchTimer),i.searchRequestId+=1,i.loading=!1,window.cancelAnimationFrame(i.jumpScrollAnimation),i.jumpScrollAnimation=0,J(),F()}function U(e){let t=h();if(t.length===0)return;let n=i.selectedIndex+e;i.selectedIndex=Math.max(0,Math.min(t.length-1,n)),M(),P(),q()}function W(e){let t=h();if(t.length!==0){if(i.selectedIndex=Math.max(0,Math.min(t.length-1,e)),M(),P(),c&&i.selectedIndex===0){G(0);return}if(c&&i.selectedIndex===t.length-1){G(c.scrollHeight-c.clientHeight);return}q()}}function G(e){if(!c)return;window.cancelAnimationFrame(i.jumpScrollAnimation);let t=c.scrollTop,n=Math.max(0,c.scrollHeight-c.clientHeight),a=Math.max(0,Math.min(n,e)),o=a-t;if(Math.abs(o)<1){c.scrollTop=a;return}let s=performance.now(),l=e=>{if(!c)return;let n=Math.min(1,(e-s)/r),a=1-(1-n)**3;c.scrollTop=t+o*a,n<1?i.jumpScrollAnimation=window.requestAnimationFrame(l):i.jumpScrollAnimation=0};i.jumpScrollAnimation=window.requestAnimationFrame(l)}function K(e){if(!c)return 0;for(let t of c.querySelectorAll(`.section-title`)){let n=t.getBoundingClientRect();if(n.top<=e.top+1&&n.bottom>e.top)return n.height}return 0}function q(){if(!c)return;let e=c.querySelector(`[data-selected="true"]`);if(!e)return;let t=c.getBoundingClientRect(),n=e.getBoundingClientRect(),r=window.getComputedStyle(c),i=Number.parseFloat(r.paddingTop)||0,a=Number.parseFloat(r.paddingBottom)||0,o=t.top+i+K(t),s=t.bottom-a;n.top<o?c.scrollTop-=o-n.top:n.bottom>s&&(c.scrollTop+=n.bottom-s)}function J(){window.clearTimeout(i.repeatDelayTimer),window.clearInterval(i.repeatTimer),i.repeatDelayTimer=0,i.repeatTimer=0,i.repeatDirection=0}function Y(e){i.repeatDirection!==e&&(J(),i.repeatDirection=e,i.repeatDelayTimer=window.setTimeout(()=>{i.repeatTimer=window.setInterval(()=>{U(e)},54)},220))}function X(e){if((e.metaKey||e.ctrlKey)&&!e.altKey&&!e.shiftKey){let t=e.code.startsWith(`Digit`)?Number(e.code.slice(5)):Number(e.key);if(Number.isInteger(t)&&t>=1&&t<=9){e.preventDefault(),B(t-1);return}if(e.key===`ArrowUp`||e.key===`Home`){e.preventDefault(),J(),W(0);return}if(e.key===`ArrowDown`||e.key===`End`){e.preventDefault(),J(),W(h().length-1);return}}if(e.key===`Escape`){e.preventDefault(),H();return}if(e.key===`ArrowDown`){e.preventDefault(),e.repeat||U(1),Y(1);return}if(e.key===`ArrowUp`){e.preventDefault(),e.repeat||U(-1),Y(-1);return}if(e.key===`Enter`){e.preventDefault(),B(i.selectedIndex);return}e.key===`Tab`&&(e.preventDefault(),v(e.shiftKey?-1:1))}function Z(e){(e.key===`ArrowDown`||e.key===`ArrowUp`)&&J()}function Q(e){e instanceof KeyboardEvent&&X(e)}function $(e){e instanceof KeyboardEvent&&Z(e)}chrome.runtime.onMessage.addListener(e=>(e?.type===`TABWEAVE_TOGGLE_COMMAND_SEARCH`&&(i.open?H():V()),!1));