import{B as e,F as t,O as n,S as r,_ as i,a,b as o,d as s,i as ee,k as c,n as te,o as l,r as ne,x as u,y as re}from"./grouping-Cpg4eUNQ.js";import{_ as d,a as f,d as ie,g as p,h as m,l as ae,m as oe,o as h,p as se,r as ce,v as g,x as _,y as v}from"./ui-_rdwf7xW.js";var y=v(),b=e(_()),x=g(),S=[`#BC82F3`,`#F5B9EA`,`#8D9FFF`,`#FF6778`,`#FFBA71`,`#C686FF`];function C(){return`conic-gradient(from 0deg, ${S.map(e=>({color:e,location:Math.random()*100})).sort((e,t)=>e.location-t.location).map(e=>`${e.color} ${e.location.toFixed(2)}%`).join(`, `)})`}var w=class{constructor(e,t){this.width=t.width,this.blur=t.blur,this.interval=t.interval*1e3,this.duration=t.duration,this.timerId=null,this.el=document.createElement(`div`),this.el.className=`aie-effect-layer`,this.blur>0&&(this.el.style.filter=`blur(${this.blur}px)`);let n=document.createElement(`div`);n.className=`aie-ring-container`,this.buffer1=this.createBuffer(),this.buffer2=this.createBuffer(),this.activeBuffer=1,this.setGradient(this.buffer1,C()),this.buffer1.style.opacity=1,this.buffer2.style.opacity=0,n.appendChild(this.buffer1),n.appendChild(this.buffer2),this.el.appendChild(n),e.appendChild(this.el),this.startTimer()}createBuffer(){let e=document.createElement(`div`);return e.className=`aie-gradient-buffer`,e.style.padding=`${this.width}px`,e.style.transitionDuration=`${this.duration}s`,e.style.transitionTimingFunction=`ease-in-out`,e}setGradient(e,t){e.style.backgroundImage=t}startTimer(){this.timerId=window.setInterval(()=>{this.animate()},this.interval)}animate(){let e=C();this.activeBuffer===1?(this.setGradient(this.buffer2,e),this.buffer2.style.opacity=1,this.buffer1.style.opacity=0,this.activeBuffer=2):(this.setGradient(this.buffer1,e),this.buffer1.style.opacity=1,this.buffer2.style.opacity=0,this.activeBuffer=1)}destroy(){this.timerId&&=(window.clearInterval(this.timerId),null)}},T=`apple-intelligence-glow-styles`,E=String.raw`
.aie-glow-root {
  position: relative;
  display: inline-block;
  border-radius: var(--aie-radius, 32px);
  overflow: hidden;
}

.aie-glow-rings {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 0;
  pointer-events: none;
}

.aie-glow-content {
  position: relative;
  z-index: 1;
}

.aie-effect-layer {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  pointer-events: none;
}

.aie-ring-container {
  position: relative;
  width: 100%;
  height: 100%;
  border-radius: var(--aie-radius, 32px);
}

.aie-gradient-buffer {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border-radius: var(--aie-radius, 32px);
  background-repeat: no-repeat;
  -webkit-mask:
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask:
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask-composite: exclude;
  transition-property: opacity;
  will-change: opacity;
}
`;function D(){if(typeof document>`u`||document.getElementById(T))return;let e=document.createElement(`style`);e.id=T,e.innerHTML=E,document.head.appendChild(e)}function le({radius:e=50,className:t=``,style:n={},children:r}){let i=(0,b.useRef)(null);(0,b.useEffect)(()=>{D()},[]),(0,b.useEffect)(()=>{let e=i.current;if(!e)return;let t=[new w(e,{width:5,blur:0,interval:.4,duration:.5}),new w(e,{width:8,blur:5,interval:.4,duration:.6}),new w(e,{width:10,blur:15,interval:.4,duration:.8}),new w(e,{width:15,blur:25,interval:.5,duration:1})];return()=>{t.forEach(e=>e.destroy()),e.innerHTML=``}},[]);let a={"--aie-radius":typeof e==`number`?`${e}px`:e,...n};return(0,x.jsxs)(`div`,{className:`aie-glow-root ${t}`,style:a,children:[(0,x.jsx)(`div`,{ref:i,className:`aie-glow-rings`}),(0,x.jsx)(`div`,{className:`aie-glow-content`,children:r})]})}String.raw`
.aie-root {
  --phone-width: 360px;
  --phone-height: 720px;
  --phone-radius: 50px;
  --bezel-width: 12px;

  position: relative;
  display: inline-flex;
  justify-content: center;
  align-items: center;
  font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, sans-serif;
}

.aie-iphone-chassis {
  position: relative;
  width: var(--phone-width);
  height: var(--phone-height);
  border-radius: var(--phone-radius);
  background-color: #000;
  box-shadow:
    0 0 0 6px #333,
    0 0 0 7px #000,
    0 20px 50px rgba(0, 0, 0, 0.5);
  z-index: 1;
  overflow: hidden;
}

.aie-glow-container {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 10;
  pointer-events: none;
}

.aie-effect-layer {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  pointer-events: none;
}

.aie-ring-container {
  position: relative;
  width: 100%;
  height: 100%;
  border-radius: var(--phone-radius);
}

.aie-gradient-buffer {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border-radius: var(--phone-radius);
  background-repeat: no-repeat;
  -webkit-mask:
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask:
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask-composite: exclude;
  transition-property: opacity;
  will-change: opacity;
}

.aie-wallpaper {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(180deg, #000000 0%, #1a1a1a 100%);
  z-index: 0;
  opacity: 0.9;
}

.aie-ui-layer {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 20;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  padding: 20px;
  color: white;
  pointer-events: none;
}

.aie-dynamic-island {
  width: 120px;
  height: 35px;
  background-color: black;
  border-radius: 20px;
  margin-top: 8px;
  z-index: 30;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-shrink: 0;
}

.aie-island-sensors {
  width: 40%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  padding-right: 8px;
}

.aie-island-dot {
  width: 8px;
  height: 8px;
  background: #1a1a1a;
  border-radius: 50%;
  box-shadow: 0 0 2px rgba(255, 255, 255, 0.1);
}

.aie-lock-header {
  margin-top: 35px;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.aie-date {
  font-size: 1.3rem;
  font-weight: 500;
  color: rgba(255, 255, 255, 0.85);
  margin-bottom: 0;
}

.aie-time {
  font-size: 5.8rem;
  font-weight: 600;
  line-height: 1;
  margin: 0;
  color: rgba(255, 255, 255, 1);
  letter-spacing: -1px;
  text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
}

.aie-bottom-bar {
  width: 130px;
  height: 5px;
  background-color: rgba(255, 255, 255, 0.5);
  border-radius: 10px;
  margin-bottom: 8px;
  margin-top: auto;
}

.aie-helper-text {
  margin-top: 8px;
  color: #666;
  font-size: 0.9rem;
  text-align: center;
}
`;var ue=5200;function O(){return typeof chrome<`u`&&!!(chrome.tabs&&chrome.tabGroups)}function k(e){try{return new URL(e.url).hostname.replace(/^www\./,``).charAt(0).toUpperCase()||`•`}catch{return`•`}}function A(e){return{id:crypto.randomUUID(),target:`url`,mode:`contains`,pattern:e.url.trim()}}function de(e,t){let n=new Set,r=t.map(A).filter(e=>{let t=e.pattern;return n.has(t)?!1:(n.add(t),!!e.pattern)}),[i]=r,a=Date.now();return{id:crypto.randomUUID(),name:e,enabled:!0,target:i?.target??`url`,mode:i?.mode??`contains`,pattern:i?.pattern??e,conditions:r.length>0?r:[{id:crypto.randomUUID(),target:`url`,mode:`contains`,pattern:e}],groupTitle:e,color:`blue`,scope:`currentWindow`,createdAt:a,updatedAt:a}}function j({tab:e,className:t=``}){let[n,r]=(0,b.useState)(!1);return e.favIconUrl&&!n?(0,x.jsx)(`span`,{className:`flex h-5 w-5 shrink-0 items-center justify-center overflow-hidden rounded-md bg-zinc-800 ring-1 ring-white/10 ${t}`,children:(0,x.jsx)(`img`,{src:e.favIconUrl,alt:``,className:`h-4 w-4`,onError:()=>r(!0)})}):(0,x.jsx)(`span`,{className:`flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-zinc-800 text-[10px] font-semibold text-zinc-500 ring-1 ring-white/10 ${t}`,children:k(e)})}function M(){let e=window.location.pathname.endsWith(`/sidepanel.html`),[g,_]=(0,b.useState)({groups:[],ungroupedTabs:[]}),[v,y]=(0,b.useState)(!0),[S,C]=(0,b.useState)(!1),[w,T]=(0,b.useState)(!1),[E,D]=(0,b.useState)([]),[k,A]=(0,b.useState)(``),[M,N]=(0,b.useState)(``),[fe,P]=(0,b.useState)(!1),[F,I]=(0,b.useState)(``),[pe,L]=(0,b.useState)(`system`),[R,z]=(0,b.useState)(null),[B,me]=(0,b.useState)(null),[V,H]=(0,b.useState)(null),[he,U]=(0,b.useState)(!1),[W,ge]=(0,b.useState)(),_e=(0,b.useMemo)(()=>g.ungroupedTabs.length+g.groups.reduce((e,t)=>e+t.tabs.length,0),[g]),G=(0,b.useMemo)(()=>g.ungroupedTabs.map(e=>e.id),[g.ungroupedTabs]),ve=(0,b.useMemo)(()=>new Map([...g.groups.flatMap(e=>e.tabs),...g.ungroupedTabs].map(e=>[e.id,e])),[g]),K=G.length>0&&G.every(e=>E.includes(e)),ye=g.groups.some(e=>e.collapsed),[be,xe]=(0,b.useState)({}),q=(0,b.useCallback)(e=>{let t=new Set([...e.groups.flatMap(e=>e.tabs),...e.ungroupedTabs].map(e=>e.id));_(e),D(e=>e.filter(e=>t.has(e)))},[]),J=(0,b.useCallback)(async()=>{if(!O()){y(!1);return}q(await l()),y(!1)},[q]);(0,b.useEffect)(()=>{let e=!1;return(async()=>{if(!O()){e||y(!1);return}let[t,n,i]=await Promise.all([u(),o(),re()]);m(t.themeMode);let a=await l();if(t.autoGroupOnPopupOpen){let e=await r(),n=await s(t.organizeScope);await te(e,n,t.domainFallbackGrouping,t.groupMinTabs),await ee(n),t.autoCollapseGroups&&await ne(t.organizeScope),a=await l()}e||(L(t.languageMode),z(t),me(i),ge(n),q(a),y(!1))})(),()=>{e=!0}},[q]),(0,b.useEffect)(()=>{let e=window.matchMedia(`(prefers-color-scheme: light)`),t=()=>{u().then(e=>{e.themeMode===`system`&&m(`system`)})};return e.addEventListener(`change`,t),()=>e.removeEventListener(`change`,t)},[]),(0,b.useEffect)(()=>{if(!M||fe)return;let e=window.setTimeout(()=>N(``),ue);return()=>window.clearTimeout(e)},[M,fe]),(0,b.useEffect)(()=>{if(typeof chrome>`u`||!chrome.storage?.onChanged)return;let e=(e,n)=>{n===`sync`&&e[t.preferences]&&u().then(e=>{z(e),L(e.languageMode),m(e.themeMode)}),n===`local`&&e[t.aiGroupingSettings]&&re().then(me)};return chrome.storage.onChanged.addListener(e),()=>chrome.storage.onChanged.removeListener(e)},[]),(0,b.useEffect)(()=>{if(!O())return;let e=!1,t,n=()=>{window.clearTimeout(t),t=window.setTimeout(()=>{e||J()},120)},r=()=>{document.visibilityState===`visible`&&n()};return chrome.tabs.onCreated.addListener(n),chrome.tabs.onRemoved.addListener(n),chrome.tabs.onUpdated.addListener(n),chrome.tabs.onMoved.addListener(n),chrome.tabs.onAttached.addListener(n),chrome.tabs.onDetached.addListener(n),chrome.tabGroups.onCreated.addListener(n),chrome.tabGroups.onRemoved.addListener(n),chrome.tabGroups.onUpdated.addListener(n),window.addEventListener(`focus`,n),document.addEventListener(`visibilitychange`,r),()=>{e=!0,window.clearTimeout(t),chrome.tabs.onCreated.removeListener(n),chrome.tabs.onRemoved.removeListener(n),chrome.tabs.onUpdated.removeListener(n),chrome.tabs.onMoved.removeListener(n),chrome.tabs.onAttached.removeListener(n),chrome.tabs.onDetached.removeListener(n),chrome.tabGroups.onCreated.removeListener(n),chrome.tabGroups.onRemoved.removeListener(n),chrome.tabGroups.onUpdated.removeListener(n),window.removeEventListener(`focus`,n),document.removeEventListener(`visibilitychange`,r)}},[J]),(0,b.useEffect)(()=>{if(!V&&!F)return;let e=e=>{e.key===`Escape`&&(H(null),I(``))};return document.addEventListener(`keydown`,e),()=>document.removeEventListener(`keydown`,e)},[V,F]);async function Se(){C(!0),N(``);try{N(Ce(await chrome.runtime.sendMessage({type:`TABWEAVE_REGROUP`}),R?.organizeScope??`currentWindow`)),await J()}finally{C(!1)}}function Ce(e,t){if(!e?.ok)return e?.error??X.failed;let n=e.deduplicated?.closed??0,r=e.hibernated?.discarded??0,i=e.checked??0,a=e.changed??0,o=e.consolidated??0,s=t===`allWindows`;return r>0?X.organizedWithCleanup.replace(`{closed}`,String(n)).replace(`{discarded}`,String(r)).replace(`{checked}`,String(i)).replace(`{changed}`,String(a)):n>0?(s?X.organizedAllWindowsWithDeduplication:X.organizedWithDeduplication).replace(`{closed}`,String(n)).replace(`{checked}`,String(i)).replace(`{changed}`,String(a)):o>0?X.organizedWithGroupConsolidation.replace(`{checked}`,String(i)).replace(`{changed}`,String(a)).replace(`{groups}`,String(o)):(s?X.organizedAllWindows:X.organized).replace(`{checked}`,String(i)).replace(`{changed}`,String(a))}async function we(){C(!0),N(``);try{let e=await chrome.runtime.sendMessage({type:`TABWEAVE_DEDUPLICATE`});if(!e?.ok){N(e?.error??X.failed);return}N(e.closed>0?X.deduplicated.replace(`{count}`,String(e.closed)):X.noDuplicates),await J()}finally{C(!1)}}async function Te(){C(!0),N(``);try{let e=await chrome.runtime.sendMessage({type:`TABWEAVE_HIBERNATE`});if(!e?.ok){N(e?.error??X.failed);return}ge(e),N(e.discarded>0?X.hibernated.replace(`{count}`,String(e.discarded)):X.noHibernateCandidates),await J()}finally{C(!1)}}async function Ee(){C(!0),T(!0),N(``),I(``),H(null);try{if(B?.provider===`compatible`){let e=new URL(B.baseUrl).origin;if(!await chrome.permissions.request({origins:[`${e}/*`]})){I(X.aiPermissionDenied);return}}let e=await chrome.runtime.sendMessage({type:`TABWEAVE_AI_GROUPING_PLAN`});if(!e?.ok){I(e?.error??X.failed);return}let t=e.plan;H(t),U(!1),xe(Object.fromEntries(t.groups.map((e,t)=>[`${t}-${e.tabIds.join(`-`)}`,t!==0]))),N(X.aiPlanReady.replace(`{groups}`,String(t.groups.length)).replace(`{checked}`,String(e.checked??0)))}catch(e){I(e instanceof Error?e.message:X.failed)}finally{T(!1),C(!1)}}async function De(){if(V){C(!0),N(``),I(``);try{let e=await chrome.runtime.sendMessage({type:`TABWEAVE_AI_APPLY_GROUPING_PLAN`,plan:V,saveRules:he});if(!e?.ok){I(e?.error??X.failed);return}N(X.aiApplied.replace(`{changed}`,String(e.changed??0))),H(null),U(!1),await J()}catch(e){I(e instanceof Error?e.message:X.failed)}finally{C(!1)}}}function Oe(e){let t=V?.groups[e];return t?`${e}-${t.tabIds.join(`-`)}`:String(e)}function ke(e){let t=Oe(e);xe(e=>({...e,[t]:!e[t]}))}function Y(e,t,n=!1){let r=n?t.replace(/\s+/g,` `).trim().slice(0,32):t.slice(0,32);n&&!r||H(t=>t&&{...t,groups:t.groups.map((t,n)=>n===e?{...t,title:r}:t)})}function Ae(e){H(t=>{if(!t)return t;let n=t.groups[e];return n?{...t,groups:t.groups.filter((t,n)=>n!==e),ungroupedTabIds:[...new Set([...t.ungroupedTabIds,...n.tabIds])]}:t})}function je(e,t){H(n=>{if(!n)return n;let r=n.groups.map((n,r)=>r===e?{...n,tabIds:n.tabIds.filter(e=>e!==t)}:n).filter(e=>e.tabIds.length>0);return{...n,groups:r,ungroupedTabIds:[...new Set([...n.ungroupedTabIds,t])]}})}async function Me(e,t){await chrome.tabGroups.update(e,{collapsed:!t}),await J()}async function Ne(e){let t=g.groups.filter(t=>t.collapsed!==e);t.length!==0&&(await Promise.all(t.map(t=>chrome.tabGroups.update(t.id,{collapsed:e}).catch(()=>void 0))),await J())}async function Pe(e){await chrome.tabs.remove(e),await J()}async function Fe(e){e.length!==0&&(await chrome.tabs.ungroup(e),await J())}async function Ie(e){await chrome.tabs.remove(e),await J()}async function Le(t){await chrome.tabs.update(t,{active:!0}),e||window.close()}async function Re(){if(!E.length||!k.trim())return;let e=k.trim(),t=g.ungroupedTabs.filter(e=>E.includes(e.id));if(t.length===0)return;let i=await r();await n([de(e,t),...i]),await a(E,e,`blue`),N(X.manualGroupSaved.replace(`{name}`,e)),D([]),A(``),await J()}let X=i(pe),ze=!!R,Z=R?.deduplicateOnOrganize??!1,Be=X.organize,Q=!!B?.enabled,Ve=!!B?.apiKey.split(/[,\n]/).some(e=>e.trim()),He=!!(Q&&Ve&&B?.model.trim()&&(B.provider!==`compatible`||B.baseUrl.trim())),Ue=Z?Q?`grid-cols-3`:`grid-cols-2`:Q?`grid-cols-4`:`grid-cols-3`,We=se(),Ge=V?.groups.reduce((e,t)=>e+t.tabIds.length,0)??0,$=W?X.hibernateLastResult.replace(`{count}`,String(W.discarded)).replace(`{checked}`,String(W.checked)):``;return(0,x.jsxs)(`div`,{className:`relative ${e?`h-screen w-screen min-w-[320px]`:`h-[600px] w-[420px]`}`,children:[(0,x.jsxs)(`main`,{className:`relative z-0 flex h-full w-full flex-col overflow-hidden popup-surface text-zinc-100 shadow-2xl shadow-black/40 ring-1 ring-white/10`,children:[(0,x.jsxs)(`section`,{className:`shrink-0 border-b border-white/10 px-4 py-3`,children:[(0,x.jsxs)(`div`,{className:`space-y-3`,children:[(0,x.jsxs)(`div`,{className:`flex items-start justify-between gap-3`,children:[(0,x.jsxs)(`div`,{className:`min-w-0`,children:[(0,x.jsx)(`div`,{className:`text-[11px] font-semibold uppercase tracking-[0.24em] text-violet-300`,children:`TabWeave`}),(0,x.jsx)(`h1`,{className:`mt-0.5 truncate text-xl font-semibold tracking-[-0.04em]`,title:X.popupTitle,children:X.popupTitle}),(0,x.jsx)(`p`,{className:`mt-0.5 truncate text-xs text-zinc-500`,children:X.currentWindowStats.replace(`{tabs}`,String(_e)).replace(`{groups}`,String(g.groups.length))}),$&&(0,x.jsx)(`p`,{className:`mt-0.5 truncate text-[11px] text-zinc-600`,children:$})]}),(0,x.jsx)(f,{onClick:()=>chrome.runtime.openOptionsPage(),className:`shrink-0 px-2.5 py-2 text-xs`,children:X.settings})]}),ze?(0,x.jsxs)(`div`,{className:`grid gap-2 ${Ue}`,children:[(0,x.jsx)(d,{initial:!1,children:!Z&&(0,x.jsx)(p.div,{layout:!0,initial:{opacity:0,scale:.98},animate:{opacity:1,scale:1},exit:{opacity:0,scale:.98},transition:{type:`spring`,duration:.34,bounce:0},className:`min-w-0`,children:(0,x.jsx)(f,{onClick:we,disabled:S||w||v,className:`w-full min-w-0 truncate whitespace-nowrap px-2.5 py-2 text-xs`,children:X.deduplicateNow})},`deduplicate-now`)}),(0,x.jsx)(f,{onClick:Te,disabled:S||w||v,className:`w-full min-w-0 truncate whitespace-nowrap px-2.5 py-2 text-xs`,children:X.hibernateNow}),Q&&(0,x.jsx)(f,{onClick:Ee,disabled:S||w||v||!He,className:`w-full min-w-0 truncate whitespace-nowrap px-2.5 py-2 text-xs`,title:He?X.aiOrganize:X.aiNeedsSetup,children:w?X.organizing:X.aiOrganize}),(0,x.jsx)(p.div,{layout:!0,transition:{type:`spring`,duration:.34,bounce:0},className:`min-w-0`,children:(0,x.jsx)(h,{onClick:Se,disabled:S||w||v,className:`w-full min-w-0 truncate whitespace-nowrap px-2.5 py-2 text-xs transition-[box-shadow,transform] ${Z?`shadow-lg shadow-emerald-500/20 ring-2 ring-emerald-300/40`:``}`,title:S?X.organizing:Z?X.organizeWithDeduplication:Be,children:S?X.organizing:Be})})]}):(0,x.jsx)(`div`,{className:`h-8`,"aria-hidden":`true`})]}),(0,x.jsx)(d,{initial:!1,children:M&&(0,x.jsx)(p.div,{className:`theme-light-toast mt-3 rounded-xl bg-violet-500/10 px-3 py-2 text-xs text-violet-200`,initial:{opacity:0,y:-4},animate:{opacity:1,y:0},exit:{opacity:0,y:-4},transition:{duration:.16},onMouseEnter:()=>P(!0),onMouseLeave:()=>P(!1),onFocus:()=>P(!0),onBlur:()=>P(!1),children:M},`status-message`)})]}),(0,x.jsxs)(`section`,{className:`soft-scrollbar scroll-mask-y-10 min-h-0 flex-1 overflow-auto pb-4`,children:[!O()&&(0,x.jsx)(`div`,{className:`px-4 pt-4`,children:(0,x.jsx)(ce,{title:X.runtimeTitle,description:X.runtimeDesc})}),O()&&v&&(0,x.jsx)(`div`,{className:`px-4 py-12 text-center text-sm text-zinc-500`,children:X.loadingTabs}),!v&&O()&&(0,x.jsxs)(`div`,{className:`space-y-5`,children:[(0,x.jsxs)(`div`,{children:[(0,x.jsxs)(`div`,{className:`sticky top-0 z-20 mb-3 flex min-h-11 items-center justify-between border-b border-white/10 bg-zinc-950 px-2.5 py-2 shadow-[0_10px_24px_rgba(9,9,11,.72)] theme-light-soft-sticky`,children:[(0,x.jsx)(`h2`,{className:`text-xs font-semibold uppercase tracking-[0.18em] text-zinc-500`,children:`Groups`}),(0,x.jsxs)(`div`,{className:`flex items-center gap-1.5`,children:[(0,x.jsx)(`button`,{type:`button`,onClick:()=>void Ne(!ye),disabled:g.groups.length===0,className:`rounded-lg px-2 py-1 text-xs text-zinc-500 transition hover:bg-white/5 hover:text-zinc-200 disabled:cursor-not-allowed disabled:opacity-35`,children:ye?X.expandAllGroups:X.collapseAllGroups}),(0,x.jsx)(`span`,{className:`rounded-xl bg-zinc-900/70 px-2 py-1 text-xs font-medium text-zinc-500 ring-1 ring-white/10`,children:g.groups.length})]})]}),g.groups.length===0?(0,x.jsx)(`div`,{className:`px-2.5`,children:(0,x.jsx)(ce,{title:X.noGroups,description:X.noGroupsDesc})}):(0,x.jsx)(`div`,{className:`space-y-3 px-2.5`,children:g.groups.map(e=>(0,x.jsxs)(`div`,{className:`rounded-2xl bg-white/[0.04] p-3 ring-1 ring-white/10`,children:[(0,x.jsxs)(`div`,{className:`flex items-center gap-2 rounded-xl`,children:[(0,x.jsxs)(`button`,{onClick:()=>Me(e.id,e.collapsed),className:`group/header flex min-w-0 flex-1 items-center gap-2 rounded-xl px-2 py-1.5 text-left transition hover:bg-white/5`,children:[(0,x.jsx)(`span`,{className:`h-2.5 w-2.5 rounded-full ${c[e.color]}`}),(0,x.jsx)(`span`,{className:`truncate text-sm font-semibold`,children:e.title}),(0,x.jsx)(`span`,{className:`text-xs text-zinc-500`,children:e.tabs.length}),(0,x.jsx)(`svg`,{className:`h-3.5 w-3.5 shrink-0 text-zinc-500 transition-transform duration-300 ${e.collapsed?`-rotate-90`:`rotate-0`}`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,"aria-hidden":`true`,children:(0,x.jsx)(`path`,{d:`m6 9 6 6 6-6`})})]}),(0,x.jsx)(`button`,{type:`button`,onClick:()=>void Fe(e.tabs.map(e=>e.id)),className:`shrink-0 whitespace-nowrap rounded-lg px-2 py-1 text-xs text-zinc-500 transition hover:bg-white/5 hover:text-zinc-200`,title:X.ungroupGroup,children:X.ungroupGroup}),(0,x.jsx)(`button`,{type:`button`,onClick:()=>void Pe(e.tabs.map(e=>e.id)),className:`shrink-0 whitespace-nowrap rounded-lg px-2 py-1 text-xs text-zinc-500 transition hover:bg-red-500/10 hover:text-red-300`,title:X.closeGroup,children:X.close})]}),(0,x.jsx)(`div`,{className:`grid transition-[grid-template-rows,opacity] duration-300 ease-out ${e.collapsed?`grid-rows-[0fr] opacity-0`:`grid-rows-[1fr] opacity-100`}`,children:(0,x.jsx)(`div`,{className:`min-h-0 overflow-hidden`,children:(0,x.jsxs)(`div`,{className:`mt-3 space-y-1.5`,children:[e.tabs.slice(0,5).map(e=>(0,x.jsxs)(`div`,{className:`flex items-center gap-1 rounded-lg px-2 py-1.5 hover:bg-white/5`,children:[(0,x.jsxs)(`button`,{onClick:()=>Le(e.id),className:`flex min-w-0 flex-1 items-center gap-2.5 text-left`,children:[(0,x.jsx)(j,{tab:e}),(0,x.jsxs)(`span`,{className:`min-w-0 flex-1`,children:[(0,x.jsx)(`span`,{className:`block truncate text-xs font-medium text-zinc-300`,children:e.title}),(0,x.jsx)(`span`,{className:`block truncate text-[11px] text-zinc-600`,children:e.url})]})]}),(0,x.jsx)(`button`,{onClick:()=>Ie(e.id),className:`shrink-0 whitespace-nowrap rounded-md px-1.5 py-1 text-[11px] text-zinc-600 transition hover:bg-red-500/10 hover:text-red-300`,title:X.closeTab,children:X.close})]},e.id)),e.tabs.length>5&&(0,x.jsx)(`div`,{className:`px-2 pt-1 text-xs text-zinc-600`,children:X.moreTabs.replace(`{count}`,String(e.tabs.length-5))})]})})})]},e.id))})]}),(0,x.jsxs)(`div`,{children:[(0,x.jsxs)(`div`,{className:`sticky top-0 z-20 mb-3 flex min-h-11 items-center justify-between border-b border-white/10 bg-zinc-950 px-2.5 py-2 shadow-[0_10px_24px_rgba(9,9,11,.72)] theme-light-soft-sticky`,children:[(0,x.jsx)(`h2`,{className:`text-xs font-semibold uppercase tracking-[0.18em] text-zinc-500`,children:`Ungrouped`}),(0,x.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,x.jsx)(`button`,{type:`button`,onClick:()=>D(K?[]:G),disabled:G.length===0,className:`rounded-lg px-2 py-1 text-xs text-zinc-500 transition hover:bg-white/5 hover:text-zinc-200 disabled:cursor-not-allowed disabled:opacity-40`,children:K?X.clearSelection:X.selectAllTabs}),(0,x.jsx)(`span`,{className:`rounded-xl bg-zinc-900/70 px-2 py-1 text-xs font-medium text-zinc-500 ring-1 ring-white/10`,children:g.ungroupedTabs.length})]})]}),(0,x.jsxs)(`div`,{className:`space-y-2 px-2.5`,children:[g.ungroupedTabs.map(e=>(0,x.jsxs)(`div`,{className:`flex items-center gap-3 rounded-xl bg-white/[0.04] px-3 py-2 ring-1 ring-white/10`,children:[(0,x.jsx)(`input`,{type:`checkbox`,checked:E.includes(e.id),onChange:t=>D(n=>t.target.checked?[...n,e.id]:n.filter(t=>t!==e.id)),className:`accent-violet-500`,"aria-label":`${X.add} ${e.title}`}),(0,x.jsx)(j,{tab:e}),(0,x.jsxs)(`button`,{type:`button`,onClick:()=>Le(e.id),className:`min-w-0 flex-1 text-left`,children:[(0,x.jsx)(`div`,{className:`truncate text-xs font-medium text-zinc-200`,children:e.title}),(0,x.jsx)(`div`,{className:`truncate text-[11px] text-zinc-600`,children:e.url})]}),(0,x.jsx)(`button`,{type:`button`,onClick:()=>Ie(e.id),className:`shrink-0 whitespace-nowrap rounded-md px-1.5 py-1 text-[11px] text-zinc-600 transition hover:bg-red-500/10 hover:text-red-300`,title:X.closeTab,children:X.close})]},e.id)),g.ungroupedTabs.length===0&&(0,x.jsx)(`div`,{className:`px-2.5 text-xs text-zinc-600`,children:X.allGrouped})]})]})]})]}),(0,x.jsx)(`section`,{className:`shrink-0 border-t border-white/10 bg-zinc-950/90 p-2.5 shadow-[0_-10px_24px_rgba(9,9,11,.22)] theme-light-footer-divider`,children:E.length>0?(0,x.jsxs)(x.Fragment,{children:[(0,x.jsx)(`div`,{className:`mb-2 flex items-center justify-between gap-3 text-xs`,children:(0,x.jsxs)(`div`,{children:[(0,x.jsx)(`span`,{className:`font-medium text-zinc-300`,children:X.manualGroup}),(0,x.jsx)(`span`,{className:`ml-2 text-zinc-600`,children:X.selectedTabs.replace(`{count}`,String(E.length))})]})}),(0,x.jsxs)(`div`,{className:`flex gap-2`,children:[(0,x.jsx)(ae,{value:k,onChange:e=>A(e.target.value),placeholder:X.groupNamePlaceholder}),(0,x.jsx)(h,{onClick:Re,disabled:!k.trim(),className:`shrink-0`,children:X.createGroup})]})]}):(0,x.jsxs)(`div`,{className:`flex items-center justify-between gap-3 text-xs`,children:[(0,x.jsx)(`span`,{className:`min-w-0 truncate text-zinc-600`,children:X.selectToGroup}),(0,x.jsxs)(`span`,{className:`flex shrink-0 items-center gap-2`,children:[(0,x.jsx)(`button`,{type:`button`,onClick:()=>void oe(ie),className:`text-zinc-500 underline decoration-zinc-700/60 underline-offset-4 transition hover:text-violet-300 hover:decoration-violet-400/40`,children:X.feedback}),(0,x.jsxs)(`span`,{className:`text-zinc-700`,children:[`v`,We]})]})]})}),(0,x.jsxs)(d,{children:[F&&(0,x.jsx)(p.div,{className:`fixed inset-0 z-[95] flex items-center justify-center bg-zinc-950/50 p-4 backdrop-blur-sm`,initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},transition:{duration:.16},onClick:()=>I(``),children:(0,x.jsxs)(p.section,{role:`alertdialog`,"aria-modal":`true`,"aria-labelledby":`ai-error-title`,className:`ai-plan-modal flex max-h-[min(520px,calc(100dvh-2rem))] w-full max-w-[520px] flex-col overflow-hidden rounded-[22px] bg-zinc-950/96 text-zinc-100 shadow-2xl shadow-black/50 ring-1 ring-white/12`,initial:{opacity:0,y:18,scale:.97},animate:{opacity:1,y:0,scale:1},exit:{opacity:0,y:14,scale:.97},transition:{type:`spring`,duration:.3,bounce:0},onClick:e=>e.stopPropagation(),children:[(0,x.jsxs)(`div`,{className:`ai-plan-modal-header flex shrink-0 items-start justify-between gap-3 border-b border-white/10 px-4 py-4`,children:[(0,x.jsxs)(`div`,{className:`min-w-0`,children:[(0,x.jsx)(`h2`,{id:`ai-error-title`,className:`text-base font-semibold tracking-[-0.02em]`,children:X.aiGrouping}),(0,x.jsx)(`p`,{className:`mt-1 text-xs text-zinc-500`,children:X.failed})]}),(0,x.jsx)(`button`,{type:`button`,onClick:()=>I(``),className:`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-zinc-500 transition hover:bg-white/5 hover:text-zinc-200`,"aria-label":X.close,children:(0,x.jsxs)(`svg`,{className:`h-4 w-4`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,"aria-hidden":`true`,children:[(0,x.jsx)(`path`,{d:`M18 6 6 18`}),(0,x.jsx)(`path`,{d:`m6 6 12 12`})]})})]}),(0,x.jsx)(`div`,{className:`ai-plan-scroll scroll-mask-y-8 min-h-0 flex-1 overflow-auto px-4 py-3`,children:(0,x.jsx)(`pre`,{className:`whitespace-pre-wrap break-words rounded-2xl bg-red-500/[0.08] px-3 py-3 font-mono text-[11px] leading-5 text-red-200 ring-1 ring-red-400/[0.15]`,children:F})}),(0,x.jsx)(`div`,{className:`ai-plan-modal-footer flex shrink-0 justify-end border-t border-white/10 bg-zinc-950/90 px-4 py-3`,children:(0,x.jsx)(f,{onClick:()=>I(``),className:`px-3 py-1.5 text-xs`,children:X.close})})]})},`ai-error-modal`),V&&(0,x.jsx)(p.div,{className:`fixed inset-0 z-[90] flex items-center justify-center bg-zinc-950/55 p-4 backdrop-blur-md`,initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},transition:{duration:.18},onClick:()=>{H(null),U(!1)},children:(0,x.jsxs)(p.section,{role:`dialog`,"aria-modal":`true`,"aria-labelledby":`ai-plan-title`,className:`ai-plan-modal flex max-h-[min(680px,calc(100dvh-2rem))] w-full max-w-[520px] flex-col overflow-hidden rounded-[24px] bg-zinc-950/96 text-zinc-100 shadow-2xl shadow-black/50 ring-1 ring-white/12`,initial:{opacity:0,y:22,scale:.96},animate:{opacity:1,y:0,scale:1},exit:{opacity:0,y:18,scale:.96},transition:{type:`spring`,duration:.34,bounce:0},onClick:e=>e.stopPropagation(),children:[(0,x.jsx)(`div`,{className:`ai-plan-modal-header shrink-0 border-b border-white/10 px-4 py-4`,children:(0,x.jsxs)(`div`,{className:`flex items-start justify-between gap-3`,children:[(0,x.jsxs)(`div`,{className:`min-w-0`,children:[(0,x.jsxs)(`div`,{className:`flex min-w-0 items-center gap-2`,children:[(0,x.jsx)(`h2`,{id:`ai-plan-title`,className:`text-lg font-semibold tracking-[-0.03em]`,children:X.aiPlanTitle}),(0,x.jsx)(`span`,{className:`shrink-0 rounded-full bg-white/[0.06] px-2 py-0.5 text-[11px] font-medium text-zinc-500 ring-1 ring-white/10`,children:X.aiPlanTabCount.replace(`{count}`,String(Ge))})]}),(0,x.jsx)(`p`,{className:`mt-1 text-xs leading-5 text-zinc-500`,children:X.aiPlanDesc})]}),(0,x.jsx)(`button`,{type:`button`,onClick:()=>{H(null),U(!1)},className:`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-zinc-500 transition hover:bg-white/5 hover:text-zinc-200`,"aria-label":X.close,children:(0,x.jsxs)(`svg`,{className:`h-4 w-4`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,"aria-hidden":`true`,children:[(0,x.jsx)(`path`,{d:`M18 6 6 18`}),(0,x.jsx)(`path`,{d:`m6 6 12 12`})]})})]})}),(0,x.jsx)(`div`,{className:`ai-plan-scroll soft-scrollbar scroll-mask-y-8 min-h-0 flex-1 space-y-3 overflow-auto px-3 py-3`,children:V.groups.length===0?(0,x.jsx)(`div`,{className:`rounded-2xl bg-white/[0.04] px-4 py-8 text-center text-sm text-zinc-500 ring-1 ring-white/10`,children:X.aiNoPlan}):V.groups.map((e,t)=>{let n=Oe(t),r=!!be[n];return(0,x.jsxs)(`div`,{className:`ai-plan-card rounded-2xl bg-white/[0.04] p-3 ring-1 ring-white/10`,children:[(0,x.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,x.jsx)(`button`,{type:`button`,onClick:()=>ke(t),className:`ai-plan-card-button group/header flex min-w-0 flex-1 items-center justify-between gap-2 rounded-xl px-1.5 py-1.5 text-left transition hover:bg-white/5`,children:(0,x.jsxs)(`span`,{className:`flex min-w-0 items-center gap-1.5`,children:[(0,x.jsx)(`span`,{className:`h-2.5 w-2.5 rounded-full ${c[e.color]}`}),(0,x.jsx)(`input`,{value:e.title,"data-previous-title":e.title,onClick:e=>e.stopPropagation(),onChange:e=>Y(t,e.target.value),onFocus:t=>{t.currentTarget.dataset.previousTitle=e.title},onBlur:n=>{let r=n.currentTarget.dataset.previousTitle||e.title;Y(t,n.currentTarget.value.trim()?n.currentTarget.value:r,!0)},onKeyDown:n=>{n.key===`Enter`&&n.currentTarget.blur(),n.key===`Escape`&&(Y(t,n.currentTarget.dataset.previousTitle||e.title),n.currentTarget.blur())},"aria-label":X.aiPlanGroupTitle,className:`ai-plan-title-input min-w-0 max-w-[180px] flex-1 rounded-lg bg-white/[0.04] px-2 py-1 text-sm font-semibold text-zinc-100 outline-none ring-1 ring-white/10 transition hover:bg-white/[0.06] hover:ring-white/15 focus:bg-white/[0.07] focus:ring-violet-400/50`}),(0,x.jsx)(`span`,{className:`text-xs text-zinc-500`,children:e.tabIds.length}),(0,x.jsx)(`svg`,{className:`h-3.5 w-3.5 shrink-0 text-zinc-500 transition-transform duration-300 ${r?`-rotate-90`:`rotate-0`}`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`2`,"aria-hidden":`true`,children:(0,x.jsx)(`path`,{d:`m6 9 6 6 6-6`})})]})}),(0,x.jsx)(`button`,{type:`button`,onClick:()=>Ae(t),className:`ai-plan-card-action shrink-0 whitespace-nowrap rounded-lg px-2 py-1 text-xs text-zinc-500 transition hover:bg-white/5 hover:text-zinc-200`,children:X.cancel})]}),e.reason&&(0,x.jsx)(`div`,{className:`mt-1 px-2 text-xs leading-5 text-zinc-600`,children:e.reason}),(0,x.jsx)(`div`,{className:`grid transition-[grid-template-rows,opacity] duration-300 ease-out ${r?`grid-rows-[0fr] opacity-0`:`grid-rows-[1fr] opacity-100`}`,children:(0,x.jsx)(`div`,{className:`min-h-0 overflow-hidden`,children:(0,x.jsx)(`div`,{className:`mt-3 space-y-1.5`,children:e.tabIds.map(e=>{let n=ve.get(e);return(0,x.jsxs)(`div`,{className:`ai-plan-tab-row flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-white/5`,children:[n?(0,x.jsx)(j,{tab:n}):(0,x.jsx)(`span`,{className:`h-5 w-5 shrink-0 rounded-md bg-zinc-800 ring-1 ring-white/10`,"aria-hidden":`true`}),(0,x.jsxs)(`span`,{className:`min-w-0 flex-1`,children:[(0,x.jsx)(`span`,{className:`block truncate text-xs font-medium text-zinc-300`,children:n?.title??`Tab ${e}`}),(0,x.jsx)(`span`,{className:`block truncate text-[11px] text-zinc-600`,children:n?.url??String(e)})]}),(0,x.jsx)(`button`,{type:`button`,onClick:()=>je(t,e),className:`ai-plan-card-action shrink-0 whitespace-nowrap rounded-md px-1.5 py-1 text-[11px] text-zinc-600 transition hover:bg-white/5 hover:text-zinc-200`,title:X.aiRemoveFromPlan,children:X.cancel})]},e)})})})})]},n)})}),(0,x.jsx)(`div`,{className:`ai-plan-modal-footer shrink-0 border-t border-white/10 bg-zinc-950/90 px-4 py-3`,children:(0,x.jsxs)(`div`,{className:`flex items-center justify-between gap-3`,children:[(0,x.jsxs)(`label`,{className:`group/save flex min-w-0 cursor-pointer items-center gap-2 rounded-xl px-1 py-1`,children:[(0,x.jsxs)(`span`,{className:`ai-plan-save-checkbox relative flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-white/[0.08] ring-1 ring-white/20 transition group-hover/save:bg-white/[0.12] focus-within:ring-2 focus-within:ring-violet-400/70`,children:[(0,x.jsx)(`input`,{type:`checkbox`,checked:he,onChange:e=>U(e.target.checked),className:`peer sr-only`}),(0,x.jsx)(`span`,{className:`absolute inset-0 rounded-md bg-violet-500 opacity-0 transition peer-checked:opacity-100`,"aria-hidden":`true`}),(0,x.jsx)(`svg`,{className:`relative h-3.5 w-3.5 scale-75 text-white opacity-0 transition peer-checked:scale-100 peer-checked:opacity-100`,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:`3`,"aria-hidden":`true`,children:(0,x.jsx)(`path`,{d:`m5 12 4 4L19 6`})})]}),(0,x.jsxs)(`span`,{className:`min-w-0`,children:[(0,x.jsx)(`span`,{className:`block truncate text-xs font-medium text-zinc-300`,children:X.aiSaveAsRules}),(0,x.jsx)(`span`,{className:`block truncate text-[11px] text-zinc-600`,children:X.aiSaveAsRulesDesc})]})]}),(0,x.jsxs)(`span`,{className:`flex shrink-0 items-center gap-2`,children:[(0,x.jsx)(f,{onClick:()=>{H(null),U(!1)},disabled:S,className:`px-3 py-1.5 text-xs`,children:X.cancel}),(0,x.jsx)(h,{onClick:De,disabled:S||Ge===0,className:`px-3 py-1.5 text-xs`,children:X.aiApplyPlan})]})]})})]})},`ai-plan-modal`)]})]}),w&&(0,x.jsx)(`div`,{className:`pointer-events-none absolute inset-0 z-40`,children:(0,x.jsx)(le,{radius:22,className:`ai-response-glow h-full w-full rounded-[22px]`,style:{width:`100%`,height:`100%`},children:(0,x.jsx)(`div`,{className:`h-full w-full rounded-[22px]`,"aria-hidden":`true`})})})]})}(0,y.createRoot)(document.getElementById(`root`)).render((0,x.jsx)(b.StrictMode,{children:(0,x.jsx)(M,{})}));