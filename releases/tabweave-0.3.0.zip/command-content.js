var e={placeholder:`Search tabs, URLs, groups, history, and commands`,loading:`Searching...`,loadingDesc:`Reading tabs, groups, commands, and history.`,noResults:`No matches found`,noResultsDesc:`Try a tab title, URL, group name, or recent page.`,hint:`Enter to open · ↑↓ to move · Esc to close`,ready:`Ready`,resultCount:`{count} results`,categoryAll:`All`,helpOpen:`Open`,helpMove:`Move`,helpCategory:`Category`,helpClose:`Close`,typeCommand:`Command`,typeTab:`Tab`,typeGroup:`Group`,typeHistory:`History`,themeMode:`light`},t=`tabweave-command-search-host`,n={open:!1,query:``,items:[],activeCategory:`all`,selectedIndex:0,loading:!1,searchTimer:0,repeatDelayTimer:0,repeatTimer:0,repeatDirection:0,copy:e},r=``,i=null,a=null,o=null,s=null,c=null,l=null;function u(){let e=document.getElementById(t);if(e?.shadowRoot)return i=e.shadowRoot,i;let r=document.createElement(`div`);return r.id=t,r.style.all=`initial`,document.documentElement.append(r),i=r.attachShadow({mode:`open`}),i.innerHTML=`
    <style>
      :host {
        all: initial;
        color-scheme: light;
        --tw-panel: #ffffff;
        --tw-search: #ffffff;
        --tw-item-hover: rgba(24, 24, 27, .045);
        --tw-item-selected: rgba(139, 92, 246, .1);
        --tw-icon-bg: rgba(244, 244, 245, .96);
        --tw-tag-bg: rgba(244, 244, 245, .9);
        --tw-border: rgba(24, 24, 27, .1);
        --tw-shadow-lg: rgba(24, 24, 27, .22);
        --tw-shadow-md: rgba(24, 24, 27, .16);
        --tw-shadow-sm: rgba(24, 24, 27, .08);
        --tw-surface-highlight: rgba(255, 255, 255, .82);
        --tw-backdrop: rgba(0, 0, 0, .08);
        --tw-muted: #71717a;
        --tw-subtle: #a1a1aa;
        --tw-text: #18181b;
        --tw-violet: #8b5cf6;
        --tw-violet-soft: rgba(139, 92, 246, .14);
        --tw-violet-ring: rgba(124, 58, 237, .22);
        --tw-key-bg: rgba(255, 255, 255, .9);
        --tw-tag-command-bg: rgba(139, 92, 246, .1);
        --tw-tag-command-text: #7c3aed;
        --tw-tag-tab-bg: rgba(14, 165, 233, .1);
        --tw-tag-tab-text: #0284c7;
        --tw-tag-group-bg: rgba(16, 185, 129, .1);
        --tw-tag-group-text: #059669;
        --tw-tag-history-bg: rgba(245, 158, 11, .12);
        --tw-tag-history-text: #b45309;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        font-size: 10px;
        line-height: 1.3;
        -webkit-font-smoothing: antialiased;
      }

      *,
      *::before,
      *::after {
        box-sizing: border-box;
        font-family: inherit;
      }

      :host([data-theme="dark"]) {
        color-scheme: dark;
        --tw-panel: #09090b;
        --tw-search: #09090b;
        --tw-item-hover: rgba(255, 255, 255, .04);
        --tw-item-selected: rgba(139, 92, 246, .16);
        --tw-icon-bg: rgba(24, 24, 27, .9);
        --tw-tag-bg: rgba(24, 24, 27, .78);
        --tw-border: rgba(255, 255, 255, .1);
        --tw-shadow-lg: rgba(0, 0, 0, .55);
        --tw-shadow-md: rgba(0, 0, 0, .38);
        --tw-shadow-sm: rgba(0, 0, 0, .22);
        --tw-surface-highlight: rgba(255, 255, 255, .08);
        --tw-backdrop: rgba(0, 0, 0, .14);
        --tw-muted: #71717a;
        --tw-subtle: #52525b;
        --tw-text: #f4f4f5;
        --tw-violet-soft: rgba(139, 92, 246, .16);
        --tw-violet-ring: rgba(196, 181, 253, .25);
        --tw-key-bg: rgba(255, 255, 255, .06);
        --tw-tag-command-bg: rgba(139, 92, 246, .16);
        --tw-tag-command-text: #c4b5fd;
        --tw-tag-tab-bg: rgba(14, 165, 233, .16);
        --tw-tag-tab-text: #7dd3fc;
        --tw-tag-group-bg: rgba(16, 185, 129, .16);
        --tw-tag-group-text: #6ee7b7;
        --tw-tag-history-bg: rgba(245, 158, 11, .16);
        --tw-tag-history-text: #fcd34d;
      }

      [hidden] { display: none !important; }

      .backdrop {
        position: fixed;
        inset: 0;
        z-index: 2147483647;
        display: grid;
        align-items: start;
        justify-items: center;
        padding-top: max(80px, 12vh);
        background: var(--tw-backdrop);
      }

      .frame {
        display: flex;
        flex-direction: column;
        width: min(680px, calc(100vw - 32px));
        height: min(560px, calc(100vh - 80px));
        max-height: min(620px, calc(100vh - 80px));
        overflow: hidden;
        overflow-x: hidden;
        border-radius: 22px;
        background:
          var(--tw-panel);
        box-shadow:
          0 42px 120px -44px var(--tw-shadow-lg),
          0 24px 60px -28px var(--tw-shadow-md),
          0 8px 24px -12px var(--tw-shadow-sm),
          inset 0 1px 0 var(--tw-surface-highlight),
          0 0 0 1px var(--tw-border);
      }

      .search {
        display: flex;
        align-items: center;
        gap: 12px;
        flex: 0 0 auto;
        padding: 12px 14px;
        background: var(--tw-search);
        border-bottom: 1px solid var(--tw-border);
      }

      .categories {
        display: flex;
        gap: 6px;
        overflow: auto;
        overflow-x: hidden;
        flex: 0 0 auto;
        padding: 7px 10px;
        border-bottom: 1px solid var(--tw-border);
        scrollbar-width: none;
      }

      .categories::-webkit-scrollbar { display: none; }

      .category {
        flex: 0 0 auto;
        min-height: 32px;
        border: 0;
        border-radius: 9px;
        padding: 0 12px;
        background: transparent;
        color: var(--tw-muted);
        font-family: inherit !important;
        font-size: 12px !important;
        font-weight: 700 !important;
        line-height: 32px !important;
        cursor: pointer;
        transition: background-color .14s ease, color .14s ease, box-shadow .14s ease;
      }

      .category:hover {
        background: var(--tw-item-hover);
        color: var(--tw-text);
      }

      .category[data-active="true"] {
        background: var(--tw-violet-soft);
        color: var(--tw-violet);
        box-shadow: inset 0 0 0 1px var(--tw-violet-ring);
      }

      .mark {
        display: grid;
        width: 30px;
        height: 30px;
        place-items: center;
        border-radius: 10px;
        background: var(--tw-violet-soft);
        color: var(--tw-violet);
        box-shadow: inset 0 0 0 1px var(--tw-violet-ring);
        font-family: inherit !important;
        font-size: 14px !important;
        font-weight: 700 !important;
        line-height: 1 !important;
      }

      input {
        all: unset;
        flex: 1;
        min-width: 0;
        height: 34px;
        color: var(--tw-text);
        font-family: inherit !important;
        font-size: 14px !important;
        font-weight: 500 !important;
        line-height: 34px !important;
      }

      input::placeholder { color: var(--tw-muted); }

      .esc {
        border-radius: 9px;
        padding: 7px 10px;
        background: var(--tw-tag-bg);
        color: var(--tw-muted);
        font-family: inherit !important;
        font-size: 12px !important;
        font-weight: 600 !important;
        line-height: 1 !important;
        box-shadow: inset 0 0 0 1px var(--tw-border);
      }

      .list {
        position: relative;
        min-height: 0;
        flex: 1 1 auto;
        overflow: auto;
        padding: 12px 8px;
        scrollbar-color: #3f3f46 transparent;
        scrollbar-width: thin;
      }

      .item {
        display: flex;
        width: 100%;
        max-width: 100%;
        min-width: 0;
        align-items: center;
        gap: 8px;
        border: 0;
        border-radius: 12px;
        background: transparent;
        padding: 7px 8px;
        color: inherit;
        text-align: left;
        font-family: inherit !important;
        font-size: 10px !important;
        font-weight: 400 !important;
        line-height: 1.3 !important;
        transition: background-color .14s ease, transform .14s ease, box-shadow .14s ease;
        cursor: pointer;
      }

      .item:hover,
      .item[data-selected="true"] {
        background: var(--tw-item-selected);
        box-shadow: inset 0 0 0 1px rgba(139, 92, 246, .18);
      }

      .item:hover { background: var(--tw-item-hover); }

      .item[data-selected="true"]:hover { background: var(--tw-item-selected); }

      .item:active { transform: scale(.96); }

      .icon {
        display: grid;
        width: 30px;
        height: 30px;
        place-items: center;
        flex: 0 0 auto;
        overflow: hidden;
        border-radius: 9px;
        background: var(--tw-icon-bg);
        color: var(--tw-violet);
        font-family: inherit !important;
        font-size: 11px !important;
        font-weight: 700 !important;
        line-height: 1 !important;
        box-shadow: inset 0 0 0 1px var(--tw-border);
      }

      .icon[data-type="command"] {
        font-size: 17px !important;
        font-weight: 700 !important;
      }

      .icon img {
        width: 20px;
        height: 20px;
      }

      .globe {
        position: relative;
        width: 18px;
        height: 18px;
        border: 1.5px solid currentColor;
        border-radius: 999px;
        opacity: .86;
      }

      .globe::before,
      .globe::after {
        content: "";
        position: absolute;
        inset: 3px 6px;
        border-left: 1px solid currentColor;
        border-right: 1px solid currentColor;
        border-radius: 999px;
      }

      .globe::after {
        inset: 8px 2px auto;
        height: 1px;
        border: 0;
        border-top: 1px solid currentColor;
        border-radius: 0;
      }

      .copy {
        min-width: 0;
        flex: 1;
        overflow: hidden;
        padding-right: 56px;
      }

      .title {
        overflow: hidden;
        display: block;
        color: var(--tw-text);
        font-family: inherit !important;
        font-size: 15px !important;
        font-weight: 500 !important;
        line-height: 1.18 !important;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .subtitle {
        margin-top: 1px;
        overflow: hidden;
        display: block;
        color: var(--tw-subtle);
        font-family: inherit !important;
        font-size: 12.5px !important;
        font-weight: 500 !important;
        line-height: 1.18 !important;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .tag {
        flex: 0 0 auto;
        max-width: 84px;
        margin-left: 18px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        border-radius: 8px;
        padding: 4px 7px;
        background: var(--tw-tag-bg);
        color: var(--tw-subtle);
        font-family: inherit !important;
        font-size: 11px !important;
        font-weight: 700 !important;
        line-height: 1 !important;
        letter-spacing: 0;
        box-shadow: none;
      }

      .tag[data-type="command"] {
        background: var(--tw-tag-command-bg);
        color: var(--tw-tag-command-text);
      }

      .tag[data-type="tab"] {
        background: var(--tw-tag-tab-bg);
        color: var(--tw-tag-tab-text);
      }

      .tag[data-type="group"] {
        background: var(--tw-tag-group-bg);
        color: var(--tw-tag-group-text);
      }

      .tag[data-type="history"] {
        background: var(--tw-tag-history-bg);
        color: var(--tw-tag-history-text);
      }

      .empty {
        padding: 42px 24px;
        text-align: center;
      }

      .empty-title {
        color: var(--tw-text);
        font-family: inherit !important;
        font-size: 14px !important;
        font-weight: 700 !important;
        line-height: 1.4 !important;
      }

      .empty-desc {
        margin-top: 6px;
        color: var(--tw-muted);
        font-family: inherit !important;
        font-size: 12px !important;
        font-weight: 500 !important;
        line-height: 1.5 !important;
      }

      .status {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        min-width: 0;
        border-top: 1px solid var(--tw-border);
        flex: 0 0 auto;
        min-height: 38px;
        padding: 10px 16px;
        color: var(--tw-muted);
        font-family: inherit !important;
        font-size: 11px !important;
        font-weight: 600 !important;
        line-height: 1.2 !important;
      }

      .status span {
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .help {
        display: flex;
        min-width: 0;
        flex-wrap: wrap;
        align-items: center;
        column-gap: 12px;
        row-gap: 5px;
      }

      .help-item {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        white-space: nowrap;
      }

      .key {
        display: inline-grid;
        min-width: 21px;
        height: 19px;
        place-items: center;
        border-radius: 5px;
        padding: 0 5px;
        background: var(--tw-key-bg);
        color: var(--tw-text);
        font-family: inherit !important;
        font-size: 10.5px !important;
        font-weight: 700 !important;
        line-height: 1 !important;
        box-shadow: inset 0 0 0 1px var(--tw-border), 0 1px 1px rgba(0, 0, 0, .04);
      }

      .count {
        display: inline-flex;
        align-items: center;
        flex: 0 0 auto;
        color: var(--tw-subtle);
        font-variant-numeric: tabular-nums;
      }

      @media (max-width: 460px) {
        .backdrop { padding-top: 56px; }
        .frame { width: calc(100vw - 20px); }
        .tag { display: none; }
      }
    </style>
    <div class="backdrop" hidden>
      <div class="frame">
        <div class="search">
          <div class="mark">⌘</div>
          <input autocomplete="off" spellcheck="false" />
          <div class="esc">Esc</div>
        </div>
        <div class="categories"></div>
        <div class="list"></div>
        <div class="status"></div>
      </div>
    </div>
  `,a=i.querySelector(`input`),o=i.querySelector(`.list`),s=i.querySelector(`.status`),c=i.querySelector(`.frame`),l=i.querySelector(`.categories`),i.querySelector(`.backdrop`)?.addEventListener(`click`,e=>{e.target instanceof Element&&e.target.classList.contains(`backdrop`)&&j()}),c?.addEventListener(`click`,e=>e.stopPropagation()),a?.addEventListener(`input`,()=>{n.query=a?.value??``,E()}),i.addEventListener(`keydown`,R),i.addEventListener(`keyup`,z),i.addEventListener(`focusout`,P),i}function d(e){return e.type===`command`?n.copy.typeCommand:e.type===`group`?n.copy.typeGroup:e.type===`history`?n.copy.typeHistory:n.copy.typeTab}function f(){return[{id:`all`,label:n.copy.categoryAll},{id:`tab`,label:n.copy.typeTab},{id:`group`,label:n.copy.typeGroup},{id:`history`,label:n.copy.typeHistory},{id:`command`,label:n.copy.typeCommand}]}function p(){return n.activeCategory===`all`?n.items:n.items.filter(e=>e.type===n.activeCategory)}function m(e){n.activeCategory=e,n.selectedIndex=0,b(),C(),w()}function h(e){let t=f();m(t[(Math.max(0,t.findIndex(e=>e.id===n.activeCategory))+e+t.length)%t.length].id)}function g(e){return e.type===`command`?`⌘`:e.type===`group`?`G`:e.type===`history`?`H`:`T`}function _(e){e.replaceChildren();let t=document.createElement(`span`);t.className=`globe`,e.append(t)}function v(){return n.copy.themeMode===`dark`||n.copy.themeMode===`system`&&window.matchMedia(`(prefers-color-scheme: dark)`).matches?`dark`:`light`}function y(){let e=i?.host;e instanceof HTMLElement&&(e.dataset.theme=v())}function b(){l&&l.replaceChildren(...f().map(e=>{let t=document.createElement(`div`);return t.role=`button`,t.tabIndex=-1,t.className=`category`,t.dataset.active=String(e.id===n.activeCategory),t.textContent=e.label,t.addEventListener(`pointerdown`,t=>{t.preventDefault(),m(e.id),a?.focus()}),t}))}function x(){let e=p();return n.loading?`loading:${n.copy.loading}:${n.copy.loadingDesc}`:e.length===0?`empty:${n.activeCategory}:${n.copy.noResults}:${n.copy.noResultsDesc}`:`${n.activeCategory}:${e.map(e=>e.id).join(`|`)}`}function S(){o?.querySelectorAll(`.item`).forEach((e,t)=>{e.dataset.selected=String(t===n.selectedIndex)})}function C(){if(!o)return;let e=x();if(e===r){S();return}if(r=e,n.loading){o.innerHTML=`<div class="empty"><div class="empty-title">${n.copy.loading}</div><div class="empty-desc">${n.copy.loadingDesc}</div></div>`;return}let t=p();if(t.length===0){o.innerHTML=`<div class="empty"><div class="empty-title">${n.copy.noResults}</div><div class="empty-desc">${n.copy.noResultsDesc}</div></div>`;return}o.replaceChildren(...t.map((e,t)=>{let r=document.createElement(`div`);r.role=`button`,r.tabIndex=-1,r.className=`item`,r.dataset.selected=String(t===n.selectedIndex),r.addEventListener(`mouseenter`,()=>{n.selectedIndex=t,S(),w(),a?.focus()}),r.addEventListener(`pointerdown`,t=>{t.preventDefault(),k(e)});let i=document.createElement(`span`);if(i.className=`icon`,i.dataset.type=e.type,e.type===`tab`&&e.favIconUrl){let t=document.createElement(`img`);t.src=e.favIconUrl,t.alt=``,t.addEventListener(`error`,()=>{_(i)}),i.append(t)}else i.textContent=g(e);let o=document.createElement(`span`);o.className=`copy`;let s=document.createElement(`span`);s.className=`title`,s.textContent=e.title;let c=document.createElement(`span`);c.className=`subtitle`,c.textContent=e.subtitle,o.append(s,c);let l=document.createElement(`span`);return l.className=`tag`,l.dataset.type=e.type,l.textContent=d(e),r.append(i,o,l),r}))}function w(){s&&(s.innerHTML=`
    <span class="help">
      <span class="help-item"><kbd class="key">↵</kbd> ${n.copy.helpOpen}</span>
      <span class="help-item"><kbd class="key">↑</kbd><kbd class="key">↓</kbd> ${n.copy.helpMove}</span>
      <span class="help-item"><kbd class="key">Tab</kbd> ${n.copy.helpCategory}</span>
      <span class="help-item"><kbd class="key">Esc</kbd> ${n.copy.helpClose}</span>
    </span>
    <span class="count">${p().length>0?n.copy.resultCount.replace(`{count}`,String(p().length)):n.copy.ready}</span>
  `)}function T(){u();let e=i?.querySelector(`.backdrop`);!e||!o||!s||!l||(y(),a&&(a.placeholder=n.copy.placeholder),e.hidden=!n.open,n.open&&(b(),C(),w()))}function E(){window.clearTimeout(n.searchTimer),n.loading=!0,T(),n.searchTimer=window.setTimeout(()=>{D()},90)}async function D(){let e=await chrome.runtime.sendMessage({type:`TABWEAVE_SEARCH_COMMANDS`,query:n.query});n.items=e?.ok?e.items??[]:[],n.selectedIndex=0,n.loading=!1,T()}async function O(){let t=await chrome.runtime.sendMessage({type:`TABWEAVE_GET_COMMAND_SEARCH_COPY`});n.copy=t?.ok&&t.copy?t.copy:e}async function k(e){(await chrome.runtime.sendMessage({type:`TABWEAVE_ACTIVATE_COMMAND_ITEM`,item:e}))?.ok&&j()}async function A(){n.open=!0,n.selectedIndex=0,n.activeCategory=`all`,u(),await O(),T(),a?.focus(),E()}function j(){n.open=!1,window.clearTimeout(n.searchTimer),P(),T()}function M(e){let t=p();if(t.length===0)return;let r=n.selectedIndex+e;n.selectedIndex=Math.max(0,Math.min(t.length-1,r)),S(),w(),N()}function N(){if(!o)return;let e=o.querySelector(`[data-selected="true"]`);if(!e)return;let t=o.getBoundingClientRect(),n=e.getBoundingClientRect(),r=window.getComputedStyle(o),i=Number.parseFloat(r.paddingTop)||0,a=Number.parseFloat(r.paddingBottom)||0,s=t.top+i,c=t.bottom-a;n.top<s?o.scrollTop-=s-n.top:n.bottom>c&&(o.scrollTop+=n.bottom-c)}function P(){window.clearTimeout(n.repeatDelayTimer),window.clearInterval(n.repeatTimer),n.repeatDelayTimer=0,n.repeatTimer=0,n.repeatDirection=0}function F(e){n.repeatDirection!==e&&(P(),n.repeatDirection=e,n.repeatDelayTimer=window.setTimeout(()=>{n.repeatTimer=window.setInterval(()=>{M(e)},54)},220))}function I(e){if(e.key===`Escape`){e.preventDefault(),j();return}if(e.key===`ArrowDown`){e.preventDefault(),e.repeat||M(1),F(1);return}if(e.key===`ArrowUp`){e.preventDefault(),e.repeat||M(-1),F(-1);return}if(e.key===`Enter`){e.preventDefault();let t=p()[n.selectedIndex];t&&k(t);return}e.key===`Tab`&&(e.preventDefault(),h(e.shiftKey?-1:1))}function L(e){(e.key===`ArrowDown`||e.key===`ArrowUp`)&&P()}function R(e){e instanceof KeyboardEvent&&I(e)}function z(e){e instanceof KeyboardEvent&&L(e)}chrome.runtime.onMessage.addListener(e=>(e?.type===`TABWEAVE_TOGGLE_COMMAND_SEARCH`&&(n.open?j():A()),!1));