import{q as e}from"./grouping-BjDWDKT2.js";import{S as t,y as n}from"./ui-CVIjAsHY.js";var r=e(t()),i=n(),a=[`#BC82F3`,`#F5B9EA`,`#8D9FFF`,`#FF6778`,`#FFBA71`,`#C686FF`];function o(){return`conic-gradient(from 0deg, ${a.map(e=>({color:e,location:Math.random()*100})).sort((e,t)=>e.location-t.location).map(e=>`${e.color} ${e.location.toFixed(2)}%`).join(`, `)})`}var s=class{constructor(e,t){this.width=t.width,this.blur=t.blur,this.interval=t.interval*1e3,this.duration=t.duration,this.timerId=null,this.el=document.createElement(`div`),this.el.className=`aie-effect-layer`,this.blur>0&&(this.el.style.filter=`blur(${this.blur}px)`);let n=document.createElement(`div`);n.className=`aie-ring-container`,this.buffer1=this.createBuffer(),this.buffer2=this.createBuffer(),this.activeBuffer=1,this.setGradient(this.buffer1,o()),this.buffer1.style.opacity=1,this.buffer2.style.opacity=0,n.appendChild(this.buffer1),n.appendChild(this.buffer2),this.el.appendChild(n),e.appendChild(this.el),this.startTimer()}createBuffer(){let e=document.createElement(`div`);return e.className=`aie-gradient-buffer`,e.style.padding=`${this.width}px`,e.style.transitionDuration=`${this.duration}s`,e.style.transitionTimingFunction=`ease-in-out`,e}setGradient(e,t){e.style.backgroundImage=t}startTimer(){this.timerId=window.setInterval(()=>{this.animate()},this.interval)}animate(){let e=o();this.activeBuffer===1?(this.setGradient(this.buffer2,e),this.buffer2.style.opacity=1,this.buffer1.style.opacity=0,this.activeBuffer=2):(this.setGradient(this.buffer1,e),this.buffer1.style.opacity=1,this.buffer2.style.opacity=0,this.activeBuffer=1)}destroy(){this.timerId&&=(window.clearInterval(this.timerId),null)}},c=`apple-intelligence-glow-styles`,l=String.raw`
.aie-glow-root {
  position: relative;
  display: inline-block;
  border-radius: var(--aie-radius, 32px);
  overflow: hidden;
}

.aie-glow-rings {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 0;
  pointer-events: none;
}

.aie-glow-content {
  position: relative;
  z-index: 1;
}

.aie-effect-layer {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  pointer-events: none;
}

.aie-ring-container {
  position: relative;
  width: 100%;
  height: 100%;
  border-radius: var(--aie-radius, 32px);
}

.aie-gradient-buffer {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border-radius: var(--aie-radius, 32px);
  background-repeat: no-repeat;
  -webkit-mask:
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask:
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask-composite: exclude;
  transition-property: opacity;
  will-change: opacity;
}
`;function u(){if(typeof document>`u`||document.getElementById(c))return;let e=document.createElement(`style`);e.id=c,e.innerHTML=l,document.head.appendChild(e)}function d({radius:e=50,className:t=``,style:n={},children:a}){let o=(0,r.useRef)(null);(0,r.useEffect)(()=>{u()},[]),(0,r.useEffect)(()=>{let e=o.current;if(!e)return;let t=[new s(e,{width:5,blur:0,interval:.4,duration:.5}),new s(e,{width:8,blur:5,interval:.4,duration:.6}),new s(e,{width:10,blur:15,interval:.4,duration:.8}),new s(e,{width:15,blur:25,interval:.5,duration:1})];return()=>{t.forEach(e=>e.destroy()),e.innerHTML=``}},[]);let c={"--aie-radius":typeof e==`number`?`${e}px`:e,...n};return(0,i.jsxs)(`div`,{className:`aie-glow-root ${t}`,style:c,children:[(0,i.jsx)(`div`,{ref:o,className:`aie-glow-rings`}),(0,i.jsx)(`div`,{className:`aie-glow-content`,children:a})]})}String.raw`
.aie-root {
  --phone-width: 360px;
  --phone-height: 720px;
  --phone-radius: 50px;
  --bezel-width: 12px;

  position: relative;
  display: inline-flex;
  justify-content: center;
  align-items: center;
  font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, sans-serif;
}

.aie-iphone-chassis {
  position: relative;
  width: var(--phone-width);
  height: var(--phone-height);
  border-radius: var(--phone-radius);
  background-color: #000;
  box-shadow:
    0 0 0 6px #333,
    0 0 0 7px #000,
    0 20px 50px rgba(0, 0, 0, 0.5);
  z-index: 1;
  overflow: hidden;
}

.aie-glow-container {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 10;
  pointer-events: none;
}

.aie-effect-layer {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  pointer-events: none;
}

.aie-ring-container {
  position: relative;
  width: 100%;
  height: 100%;
  border-radius: var(--phone-radius);
}

.aie-gradient-buffer {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border-radius: var(--phone-radius);
  background-repeat: no-repeat;
  -webkit-mask:
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask:
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask-composite: exclude;
  transition-property: opacity;
  will-change: opacity;
}

.aie-wallpaper {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(180deg, #000000 0%, #1a1a1a 100%);
  z-index: 0;
  opacity: 0.9;
}

.aie-ui-layer {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 20;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  padding: 20px;
  color: white;
  pointer-events: none;
}

.aie-dynamic-island {
  width: 120px;
  height: 35px;
  background-color: black;
  border-radius: 20px;
  margin-top: 8px;
  z-index: 30;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-shrink: 0;
}

.aie-island-sensors {
  width: 40%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  padding-right: 8px;
}

.aie-island-dot {
  width: 8px;
  height: 8px;
  background: #1a1a1a;
  border-radius: 50%;
  box-shadow: 0 0 2px rgba(255, 255, 255, 0.1);
}

.aie-lock-header {
  margin-top: 35px;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.aie-date {
  font-size: 1.3rem;
  font-weight: 500;
  color: rgba(255, 255, 255, 0.85);
  margin-bottom: 0;
}

.aie-time {
  font-size: 5.8rem;
  font-weight: 600;
  line-height: 1;
  margin: 0;
  color: rgba(255, 255, 255, 1);
  letter-spacing: -1px;
  text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
}

.aie-bottom-bar {
  width: 130px;
  height: 5px;
  background-color: rgba(255, 255, 255, 0.5);
  border-radius: 10px;
  margin-bottom: 8px;
  margin-top: auto;
}

.aie-helper-text {
  margin-top: 8px;
  color: #666;
  font-size: 0.9rem;
  text-align: center;
}
`;export{d as t};